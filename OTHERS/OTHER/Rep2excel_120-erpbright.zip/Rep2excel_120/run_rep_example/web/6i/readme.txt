test_rep.fmb	An example demonstrate how to call rep2excel from oracle forms.
test_report.rdf	A simple report
getreport.jsp	A simple JSP program which can download files from web server.